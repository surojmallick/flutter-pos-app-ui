import 'package:flutter/material.dart';
import '../db_helper.dart';

class InvoicesScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Invoices'),
      ),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: DBHelper().getInvoices(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('No invoices found'));
          } else {
            return ListView.builder(
              itemCount: snapshot.data!.length,
              itemBuilder: (context, index) {
                final invoice = snapshot.data![index];
                return Card(
                  child: ListTile(
                    title: Text(invoice['customerName']),
                    subtitle: Text('Total: ₹${invoice['total']}'),
                    trailing: Text(invoice['date']),
                  ),
                );
              },
            );
          }
        },
      ),
    );
  }
}
