import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Invoice Management UI'),
      ),
      body: GridView.count(
        crossAxisCount: 2,
        children: [
          Card(
            child: ListTile(
              title: Text('Total Product'),
              subtitle: Text('06'),
              onTap: () {},
            ),
          ),
          Card(
            child: ListTile(
              title: Text('Total Customer'),
              subtitle: Text('52'),
              onTap: () {},
            ),
          ),
          Card(
            child: ListTile(
              title: Text('Weekly Revenue'),
              subtitle: Text('₹ 4,500'),
              onTap: () {},
            ),
          ),
          Card(
            child: ListTile(
              title: Text('Total Revenue'),
              subtitle: Text('₹ 10,050'),
              onTap: () {},
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.pushNamed(context, '/create-invoice');
        },
        child: Icon(Icons.add),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Invoices'),
        ],
        onTap: (index) {
          if (index == 1) {
            Navigator.pushNamed(context, '/invoices');
          }
        },
      ),
    );
  }
}
