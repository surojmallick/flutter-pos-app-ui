import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'screens/create_invoice_screen.dart';
import 'screens/invoices_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Invoice Management System',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomeScreen(),
      routes: {
        '/create-invoice': (context) => CreateInvoiceScreen(),
        '/invoices': (context) => InvoicesScreen(),
      },
    );
  }
}
